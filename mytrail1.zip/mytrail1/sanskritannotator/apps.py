from django.apps import AppConfig


class SanskritannotatorConfig(AppConfig):
    name = 'sanskritannotator'
